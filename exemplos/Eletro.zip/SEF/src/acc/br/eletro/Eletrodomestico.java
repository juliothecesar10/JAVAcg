package acc.br.eletro;

public abstract class Eletrodomestico {
	private boolean ligado;
	private int voltagem;
	
	// m�todo abstratos n�o possuem corpo
	public abstract void ligar();
	public abstract void desligar();

	// Classes abstratas podem ter construtor, 
	// por�m nao podem ser usados para instanciar um objeto diretamente
	public Eletrodomestico(boolean ligado, int voltagem) {
		this.ligado = ligado;
		this.voltagem = voltagem;
	}
	
	// Classes abstratas podem possuir m�todos n�o abstratos
	public boolean isLigado() {
		return ligado;
	}
	public void setLigado(boolean ligado) {
		this.ligado = ligado;
	}
	public int getVoltagem() {
		return voltagem;
	}
	public void setVoltagem(int voltagem) {
		this.voltagem = voltagem;
	}
	
	
}
