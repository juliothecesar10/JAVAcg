package acc.br.cafe;

public class CafePrincipal {

	public static void main(String[] args) {

		CoffeeDrink cafe = CoffeeDrink.buildNewDrink().qtdEspresso(1);
		
		CoffeeDrink cafeComLeite = CoffeeDrink.buildNewDrink().qtdEspresso(2).comLeite();

		CoffeeDrink cafeComCanela = CoffeeDrink.buildNewDrink().qtdEspresso(1).comLeite().comCanela();

		CoffeeDrink cafeComChantilly = CoffeeDrink.buildNewDrink().qtdEspresso(1).comAcucar(2).comChantilly();
		
		System.out.println(cafe);
		System.out.println(cafeComLeite);
		System.out.println(cafeComCanela);
		System.out.println(cafeComChantilly);
	}

}
