package acc.br.cafe;

public class CoffeeDrink {
    private int espresso;
    private int acucar;
    private boolean leite;
    private boolean canela;
    private boolean chantilly;

    private CoffeeDrink() {
    }

    public static CoffeeDrink buildNewDrink() {
        return new CoffeeDrink();
    }

    @Override
	public String toString() {
		return "CoffeeDrink [espresso=" + espresso + ", acucar=" + acucar + ", leite=" + leite + ", canela=" + canela
				 + ", Chantilly=" + chantilly+ "]";
	}

	public CoffeeDrink qtdEspresso(int n) {
        this.espresso = n;
        return this;
    }

    public CoffeeDrink comAcucar(int i) {
        this.acucar = i;
        return this;
    }
    
    public CoffeeDrink comLeite() {
        this.leite = true;
        return this;
    }

    public CoffeeDrink comCanela() {
        this.canela = true;
        return this;
    }

    public CoffeeDrink comChantilly() {
        this.chantilly = true;
        return this;
    }
    
}
