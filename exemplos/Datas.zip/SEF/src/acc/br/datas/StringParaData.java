package acc.br.datas;

import java.time.LocalDate;

public class StringParaData {
	
	public static void main(String[] args) {
        LocalDate date1 = LocalDate.parse("2019-12-03");
        System.out.println(date1);     
	}
}