package acc.br.datas;

import java.time.Instant;
import java.time.ZoneId;
import java.time.format.DateTimeFormatter;
import java.time.temporal.ChronoUnit;
import java.util.Locale;

public class Instante {

	public static void main(String[] args) {
		String dataHora =
		Instant.now()                                    // Capture current moment in UTC.
	       .truncatedTo( ChronoUnit.SECONDS )            // Lop off any fractional second.
	       //.plus( 8 , ChronoUnit.HOURS )                 // Add eight hours.
	       .atZone( ZoneId.of( "America/Montreal" ) )    // Adjust from UTC to the wall-clock time used by the people of a certain region (a time zone). Returns a `ZonedDateTime` object.
	       .format(                                      // Generate a `String` object representing textually the value of the `ZonedDateTime` object.
	           DateTimeFormatter.ofPattern( "dd/MM/uuuu HH:mm:ss" )
	                            .withLocale( Locale.US ) // Specify a `Locale` to determine the human language and cultural norms used in localizing the text being generated. 
	       );
		System.out.println(dataHora);
	}

}
