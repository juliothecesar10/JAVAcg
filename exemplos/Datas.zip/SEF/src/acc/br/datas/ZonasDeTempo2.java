package acc.br.datas;

import java.time.ZoneId;

public class ZonasDeTempo2 {

	public static void main(String[] args) {
		ZoneId zoneId  = ZoneId.of("Asia/Calcutta");
		System.out.println("UTC : "+ zoneId.getRules());
	}

}
