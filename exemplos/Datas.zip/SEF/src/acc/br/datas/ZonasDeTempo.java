package acc.br.datas;

import java.util.Calendar;
import java.util.GregorianCalendar;
import java.util.TimeZone;

public class ZonasDeTempo {

   public static void main(String[] args) {
        Calendar HoraLocal = Calendar.getInstance();
        int hour = HoraLocal.get(Calendar.HOUR);
        int minute = HoraLocal.get(Calendar.MINUTE);
        int second = HoraLocal.get(Calendar.SECOND);
        int year = HoraLocal.get(Calendar.YEAR);

        System.out.printf("Hora Local: %02d:%02d:%02d %02d\n", hour, minute, second, year);
        
        // Cria um objeto calendar para representar o fuso hor�rio de Singapore.
        Calendar HoraSingapore = new GregorianCalendar(TimeZone.getTimeZone("Asia/Singapore"));
        //HoraSingapore.setTimeInMillis(HoraSingapore.getTimeInMillis());
        hour = HoraSingapore.get(Calendar.HOUR);
        minute = HoraSingapore.get(Calendar.MINUTE);
        second = HoraSingapore.get(Calendar.SECOND);
        year = HoraSingapore.get(Calendar.YEAR);
        // Fuso hor�rio da india
        System.out.printf("Hora em Singapura: %02d:%02d:%02d %02d\n", hour, minute, second, year);
        
        // Cria um objeto calendar para representar o fuso hor�rio dos EUA.
        Calendar horaEUA = new GregorianCalendar(TimeZone.getTimeZone("US/Central"));
        //horaEUA.setTimeInMillis(horaEUA.getTimeInMillis());
        hour = horaEUA.get(Calendar.HOUR);
        minute = horaEUA.get(Calendar.MINUTE);
        second = horaEUA.get(Calendar.SECOND);
        year = horaEUA.get(Calendar.YEAR);
        // Fuso hor�rio de Nova york
        System.out.printf("Hora em New York: %02d:%02d:%02d %02d\n", hour, minute, second, year);

        // Cria um objeto calendar para representar o fuso hor�rio do Brasil.
        Calendar saoPauloDate = new GregorianCalendar(TimeZone.getTimeZone("America/Sao_Paulo"));
        //saoPauloDate.setTimeInMillis(saoPauloDate.getTimeInMillis());
        hour = saoPauloDate.get(Calendar.HOUR);
        minute = saoPauloDate.get(Calendar.MINUTE);
        second = saoPauloDate.get(Calendar.SECOND);
        year = saoPauloDate.get(Calendar.YEAR);
        System.out.printf("Hora em S�o Paulo: %02d:%02d:%02d %02d\n", hour, minute, second, year);

        // Lista de todos os fusos para sua referencia
        log(TimeZone.getAvailableIDs());
    }

   private static void log(String[] availableIDs) {
        System.out.println("\nAqui a lista com todos os fusos para sua refer�ncia:");
        for (String temp : availableIDs) {
            System.out.println(temp);
        }
    }
}
