package acc.br.datas;

import java.text.SimpleDateFormat;
import java.util.Date;

public class Datapadrao {

	public static void main(String[] args) {
		Date theDateToday = new Date();
		
		System.out.println(theDateToday);
	}

}
