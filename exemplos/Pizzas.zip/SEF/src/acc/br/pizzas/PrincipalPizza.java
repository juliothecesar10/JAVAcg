package acc.br.pizzas;

public class PrincipalPizza {

	public static void main(String[] args) {
		
		Endereco endereco     = new Endereco("Rua 48", "Azul", "Talkketna", "Alaska", 99676);
		Cliente cliente       = new Cliente("Zé mané", endereco);
		Pizza pizzaMussarella = new Pizza("Mussarella", 79.90f);
		
		Pedido pedido         = new Pedido(1,cliente, pizzaMussarella);
		
		System.out.println("Cliente :" + pedido.getCliente().getNome());
		System.out.println("Endereco do pedido :" + pedido.getCliente().getEndereco().getRua());
		System.out.println("Valor do pedido :" + pedido.getPizza().getValor());
	}

}
