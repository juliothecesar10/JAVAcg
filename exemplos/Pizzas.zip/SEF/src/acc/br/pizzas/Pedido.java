package acc.br.pizzas;

public class Pedido {
	private int numPedido;
    private Cliente cliente;
    private Pizza pizza;
    
	public Pedido(int numPedido, Cliente cliente, Pizza pizza) {
		this.numPedido = numPedido;
		this.cliente = cliente;
		this.pizza = pizza;
	}

	public int getNumPedido() {
		return numPedido;
	}

	public void setNumPedido(int numPedido) {
		this.numPedido = numPedido;
	}

	public Cliente getCliente() {
		return cliente;
	}

	public void setCliente(Cliente cliente) {
		this.cliente = cliente;
	}

	public Pizza getPizza() {
		return pizza;
	}

	public void setPizza(Pizza pizza) {
		this.pizza = pizza;
	}
    
	
}
