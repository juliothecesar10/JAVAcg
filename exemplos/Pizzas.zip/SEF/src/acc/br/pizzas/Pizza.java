package acc.br.pizzas;

public class Pizza {
	private String sabor;
	private float valor;
	
	public Pizza(String sabor, float valor) {
		this.sabor = sabor;
		this.valor = valor;
	}

	public String getSabor() {
		return sabor;
	}

	public void setSabor(String sabor) {
		this.sabor = sabor;
	}

	public float getValor() {
		return valor;
	}

	public void setValor(float valor) {
		this.valor = valor;
	}
	
}
