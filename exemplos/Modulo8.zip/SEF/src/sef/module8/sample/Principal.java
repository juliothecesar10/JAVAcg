package sef.module8.sample;

public class Principal {

	public static void main(String[] args) {
		Funcionario f = new Funcionario();
		Gerente g = new Gerente();
		Vendedor v = new Vendedor();
		
		System.out.println(f.calcularSalario());
		System.out.println(g.calcularSalario());
		System.out.println(v.calcularSalario());
	}
}