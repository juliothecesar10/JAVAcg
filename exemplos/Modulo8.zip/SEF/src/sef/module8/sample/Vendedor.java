package sef.module8.sample;

public class Vendedor extends Funcionario {
	
	@Override
	public double calcularSalario() {
		return super.calcularSalario() + 600.00;
	}
}
