package sef.module8.sample;

import java.util.InputMismatchException;
import java.util.Scanner;

public class TryCatch01 {
    public static void main(String[] args) {
       
        Scanner scanner = new Scanner(System.in);
        boolean calculoRealizado = false;

        while (!calculoRealizado) {
            try {
                System.out.print("Digite o primeiro número (dividendo): ");
                int dividendo = scanner.nextInt();

                System.out.print("Digite o segundo número (divisor): ");
                int divisor = scanner.nextInt();

                int resultado = dividendo / divisor;
                System.out.println("Resultado da divisão: " + resultado);
                calculoRealizado = true;

            } catch (InputMismatchException e) {
                System.out.println("Erro: Por favor, digite apenas números inteiros.");
                scanner.next(); // Limpa o buffer do scanner

            } catch (ArithmeticException e) {
                System.out.println("Erro: Divisão por zero não é permitida.");

            } catch (Exception e) {
                System.out.println("Erro inesperado: " + e.getMessage());

            } finally {
                System.out.println("Operação concluída (com ou sem sucesso).");
            }
        }

        scanner.close();
    }
}