package sef.module8.sample;
// Needs to be completed
//Run this class with -ea option enabled in JVM arguments
public class AssertSample {

	public static void test()
	{
		//1 - Type assert 5 %2 and 6%2 in separate statements
		 int value = 19; 
	     assert value >= 20 : "Abaixo do peso..."; 
	     System.out.println("O valor �: "+value); 

	}
	public static void main(String arg[]){
		//2 - Call test()
		test();
	}			
}
