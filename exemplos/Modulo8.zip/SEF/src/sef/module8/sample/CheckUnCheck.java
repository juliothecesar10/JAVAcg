package sef.module8.sample;

import java.io.*;

public class CheckUnCheck {
	public static void main(String[] args) throws IOException 
	{
		System.out.println("Exemplo de excessão");
		System.out.println(25 / 0);
		System.out.println("Linha 10");
	}

}
