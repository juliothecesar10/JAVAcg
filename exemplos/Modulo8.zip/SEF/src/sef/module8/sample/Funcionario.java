package sef.module8.sample;

public class Funcionario {
	private double salario;
	
	public double calcularSalario() {
		salario = 500.00;
		return salario;
	}
}
