package sef.module8.sample;
// Needs to be completed
public class ArrayExceptionSample {

	public static void main(String arg[]){
		
		//The valid indices for this array are from 0 to 4
		int scores[] = new int[5];

		for (int x1 = 0; x1 < 6; x1++) {
			try {
				System.out.println(scores[x1]);
			} 
			catch (ArrayIndexOutOfBoundsException e) {
				System.out.println("Indice fora dos limites..");
			}
			catch (Exception e) {
				System.out.println("Deu ruim ");
			}
		}
		
		int x = 9;
		int y = 0;
		int resultado;
		resultado = 0;

		try {
			resultado = x / y;
		}
		catch (ArithmeticException e) {
			resultado = 0;
		}
		catch (Exception e) {
			System.out.println("Deu ruim na divisao");
		}
		finally {
			System.out.println("=" + resultado);
		}
	}
}
