package sef.module8.sample;

// Needs to be completed
public class TryCatchFinallySample {

	String str;
	
	public static void main(String[] args) {
		//1 - Create an instance of TryCatchFinallySample and call catchMeIfYouCan()
		TryCatchFinallySample obj = new TryCatchFinallySample();
		obj.catchMeIfYouCan();
	}
	
	public void catchMeIfYouCan()
	{

		System.out.println(str);
		
//		System.out.println(str.toUpperCase());
		
		try {
			System.out.println(str.toUpperCase());
		}
		catch (NullPointerException e) {
			System.out.println("String nula não pode ser alterada.");
		}
		catch (Exception e) {
			System.out.println(e);
		}
		
		System.out.println("Continuou");		
		
	}
}