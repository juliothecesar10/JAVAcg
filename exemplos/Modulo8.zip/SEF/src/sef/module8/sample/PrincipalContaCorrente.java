package sef.module8.sample;

import java.util.Date;

public class PrincipalContaCorrente {

	public static void main(String[] args) {
		Date dataHoje = new Date(); 
		ClienteDonoConta cliente1 = new ClienteDonoConta("Joao",12345678,"R. 40"); 
		ContaCorrente2 Conta1 = new ContaCorrente2(123456, cliente1, 100.00, dataHoje );

		System.out.println(Conta1.getCliente().getNome());
		Conta1.Depositar(150.00);
		Conta1.ExibirSaldo();
		
		ClienteDonoConta cliente2 = new ClienteDonoConta("Maria",12345678,"R. 38"); 
		ContaCorrente2 Conta2 = new ContaCorrente2(789,cliente2, 500.00, dataHoje );

		System.out.println(Conta2.getCliente().getNome());
		Conta2.Sacar(50.00);
		Conta2.ExibirSaldo();
		System.out.println("====================");
		Conta1.Transferir(Conta2,250.00);
		Conta1.ExibirSaldo();
		Conta2.ExibirSaldo();
		
		Conta1.Sacar(10.00);
	}

}
