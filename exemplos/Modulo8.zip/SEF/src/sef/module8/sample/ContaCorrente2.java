package sef.module8.sample;

import java.util.Date;

import sef.module5.sample.ExceptionSaldoInsuficiente;

public class ContaCorrente2 {
	private int numero;
	private ClienteDonoConta cliente;
	private double saldo;
	private Date data;
	
	public ContaCorrente2(int numero, ClienteDonoConta cliente, double saldo, Date data) {
		this.numero = numero;
		this.cliente = cliente;
		this.saldo = saldo;
		this.data = data;
	}

	public ClienteDonoConta getCliente() {
		return cliente;
	}

	public void setCliente(ClienteDonoConta cliente) {
		this.cliente = cliente;
	}

	public int getNumero() {
		return numero;
	}
	
	public void setNumero(int numero) {
		this.numero = numero;
	}
	
	public double getSaldo() {
		return saldo;
	}
	
	public void setSaldo(double saldo) {
		this.saldo = saldo;
	}
	
	public Date getData() {
		return data;
	}
	
	public void setData(Date data) {
		this.data = data;
	}
	
	public void Depositar(double valorDeposito) {
		saldo = saldo + valorDeposito;
	}

	public void Sacar(double valorSaque) {
		saldo = saldo - valorSaque;
		try {
			if (saldo < 0) {
			   throw new ExceptionSaldoInsuficiente("Operacao n�o realizada!!");
			}
		} catch (ExceptionSaldoInsuficiente e) { 
			saldo = saldo + valorSaque;
			System.out.println(e.getMessage());
		}
	}
	
	public void ExibirSaldo() {
		System.out.println("Saldo atual = "+ saldo);
	}
	
	public void Transferir(ContaCorrente2 contaDestino, double valorTransferencia) {
		if (valorTransferencia <= saldo) {
			saldo = saldo - valorTransferencia;
			contaDestino.saldo = contaDestino.saldo + valorTransferencia;
		} else {
			System.out.println("Saldo insuficiente!!!");
		}
	}
}