package sef.module8.sample;

public class Gerente extends Funcionario {

		@Override
		public double calcularSalario() {
			return super.calcularSalario() + 1000.00;
		}
}
