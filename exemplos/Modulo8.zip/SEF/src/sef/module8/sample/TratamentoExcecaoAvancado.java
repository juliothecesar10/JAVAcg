package sef.module8.sample;

import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.Scanner;

public class TratamentoExcecaoAvancado {

	public static void main(String[] args) {
		Scanner input = new Scanner(System.in);
		
		System.out.println("Entre com um String:");
		String str = input.nextLine();
		
		PrintWriter output = null;
		
		try {
			System.out.println("Tentando escrever no arquivo");
			if (str.length() > 0) {
				output = new PrintWriter(new FileWriter("output.txt"));
				output.println(str);
			} else {
				System.out.println("Input vazio");
			}
		} catch (IOException e) {  // Lan�ado pelo FilEWriter
			System.out.println("N�o pude abir o arquivo para escrita");
			System.out.println(e.toString());
		} finally {
			if (output !=null) {
				output.close();
			} else {
				System.out.println("Arquivo n�o foi escrito");
			}
		}
	}
}
