package acc.br.bichos;

public class Bird extends Oviparo {
		
   private String nome;
   
   public Bird () {
		super();
   }
   
	public String getNome() {
	return nome;
	}
	
	public void setNome(String nome) {
		this.nome = nome;
	}

	@Override
	public void emitirSOM() {
	  System.out.println("O Bird esta piando....");
	}	
}