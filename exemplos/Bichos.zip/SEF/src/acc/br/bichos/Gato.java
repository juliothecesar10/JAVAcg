package acc.br.bichos;

public class Gato implements Animali {

    @Override
    public void emitirSom() {
    	System.out.println("miau....");
    }

    @Override
    public void comer() {
    	System.out.println("comendo sem fazer barulho....");
    }

    @Override
    public void dormir() {
    	System.out.println("dormindo em lugar alto....");
    }
}
