package acc.br.bichos;

public abstract class AnimalOLD {

	public AnimalOLD() {
		super();
	}

	public void emitirSOM() {}
	
	public void mover() {}

}