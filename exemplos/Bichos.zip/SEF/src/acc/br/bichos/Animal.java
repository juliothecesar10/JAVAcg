package acc.br.bichos;

public abstract class Animal {

	public Animal() {
		super();
	}

	public void emitirSOM() {
		
	};
	
	public void mover() {
		
	};

}