package acc.br.bichos;

public class Principal {

	public static void main(String[] args) {
		Lion leao = new Lion();
		leao.emitirSOM();
		leao.mover();

		Bird passaro = new Bird();
		passaro.setNome("Pardal");
		passaro.emitirSOM();
		passaro.mover();
		System.out.println(passaro.getNome());
	}

}
