package acc.br.bichos;

public abstract class Mamiferos extends Animal {

	public Mamiferos() {
	}
	
	@Override
	public void mover() {
		System.out.println("Correndo ....");
	}
}