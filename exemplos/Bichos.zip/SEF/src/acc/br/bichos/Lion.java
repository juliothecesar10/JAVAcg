package acc.br.bichos;

public class Lion extends Mamiferos {

	public Lion() {
		super();
	}

	@Override
	public void emitirSOM() {
	  System.out.println("O Lion esta rosnando....");
	}	
}
