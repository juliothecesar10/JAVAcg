package acc.br.bichos;

public interface Animali {

	void emitirSom();
	void comer();
	void dormir();

}
