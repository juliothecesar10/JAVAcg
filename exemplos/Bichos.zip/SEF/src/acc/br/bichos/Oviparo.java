package acc.br.bichos;

public abstract class Oviparo extends Animal {

	public Oviparo() {
	}
	
	@Override
	public void mover() {
		System.out.println("Voando ....");
	}
}
