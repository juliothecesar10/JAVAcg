package acc.br.strings;

public class StringtoString {

	public static void main(String[] args) {
		Pessoa p1 = new Pessoa();
		p1.setNome("Ana");
		p1.setIdade("22");
		System.out.println(p1);

	}

}
