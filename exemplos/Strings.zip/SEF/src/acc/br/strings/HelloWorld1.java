package acc.br.strings;

public class HelloWorld1 {
	
	public static void main(String[] args) {
		String s;
		char c;
		
		s = " Texto qualquer";
		c = 'x';
				
		System.out.println("Interpolação");
		System.out.println("$s  $c");
		System.out.println("Concatenação");
		System.out.println(s + ' '+ c);
	}

}
