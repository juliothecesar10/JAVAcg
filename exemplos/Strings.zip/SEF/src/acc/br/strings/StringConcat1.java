package acc.br.strings;

public class StringConcat1 {

	 public static void main(String args[]) 
	 { 
	    String s = "ACC";
	    
	    s = s.concat("! is the best").concat(" of the world!");
	    
	    System.out.println(s);
	 } 

}
