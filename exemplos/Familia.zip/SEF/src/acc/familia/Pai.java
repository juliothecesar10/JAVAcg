package acc.familia;

 public class Pai extends Avo {
	private boolean alto;
	 
	public Pai() {
		System.out.println("Construtor do Pai");
	}

	public boolean isAlto() {
		return alto;
	}

	public void setAlto(boolean alto) {
		this.alto = alto;
	}

}