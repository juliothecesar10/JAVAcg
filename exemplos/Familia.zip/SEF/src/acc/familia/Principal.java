package acc.familia;

public class Principal {
    public static void main(String[] args) {

    	Filho filho = new Filho();
        filho.setNome("Filho");
        System.out.println(filho.getProfissao());

        filho.seApresentar();

    }
}