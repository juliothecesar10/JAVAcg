package acc.familia;

public class Filho extends Pai {
  
	public Filho() {
		System.out.println("Contrutor do Filho");

	}
	
}