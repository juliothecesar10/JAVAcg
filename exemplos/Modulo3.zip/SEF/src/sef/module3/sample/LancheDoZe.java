package sef.module2.sample;

import java.util.Scanner;

public class LancheDoZe {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        // Exibir o cardápio
        System.out.println("LANCHE DO ZÉ: Cardápio");
        System.out.println("100 - Cachorro quente - R$ 1.20");
        System.out.println("101 - Bauru simples - R$ 1.30");
        System.out.println("102 - Bauru com ovo - R$ 1.50");
        System.out.println("103 - Hambúrguer - R$ 1.20");
        System.out.println("104 - Cheeseburguer - R$ 1.30");
        System.out.println("105 - Refrigerante - R$ 1.00");
        
        // Entrada do código do item
        System.out.print("Digite o código do item desejado: ");
        int codigo = scanner.nextInt();

        // Entrada da quantidade
        System.out.print("Digite a quantidade desejada: ");
        int quantidade = scanner.nextInt();

        double preco = 0;

        // Verifica o código e define o preço
        switch (codigo) {
            case 100:
                preco = 1.20;
                break;
            case 101:
                preco = 1.30;
                break;
            case 102:
                preco = 1.50;
                break;
            case 103:
                preco = 1.20;
                break;
            case 104:
                preco = 1.30;
                break;
            case 105:
                preco = 1.00;
                break;
            default:
                System.out.println("Código inválido!");
                scanner.close();
                return;
        }

        // Calcula o valor total
        double total = preco * quantidade;
        
        // Exibe o total a ser pago
        System.out.printf("Total a pagar: R$ %.2f\n", total);
        
        scanner.close();
    }
}
