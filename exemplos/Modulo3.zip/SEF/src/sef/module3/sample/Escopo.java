package sef.module3.sample;

public class Escopo {
	public static String name = "Ligia Uchoa de Medeiros";
	
	public static void main(String[] args) {
		System.out.println(name);
		imprimirName();
		System.out.println("Final do programa");
	}
	
	public static void imprimirName() {
		String escolaNome = "RSVM";
		System.out.println(escolaNome);
		System.out.println(name);
	}
	
}