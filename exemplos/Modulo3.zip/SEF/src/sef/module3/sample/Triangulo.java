package sef.module3.sample;

import java.util.Scanner;

public class Triangulo {

	public static void main(String[] args) {
		int LadoA, LadoB, LadoC;
		Scanner meuScanner = new Scanner(System.in);
		
		System.out.println("Informe lado A: ");
		LadoA = meuScanner.nextInt();

		System.out.println("Informe lado B: ");
		LadoB = meuScanner.nextInt();
		
		System.out.println("Informe lado C: ");
		LadoC = meuScanner.nextInt();
		
		if (LadoA == LadoB) {
			if (LadoB == LadoC) {
				System.out.println("Tringulo Equilatero");
			} else {
				System.out.println("Triangulo Isoceles");
			}
		} else {
			if (LadoB == LadoC) {
				System.out.println("Triangulo Isoceles");
			} else {
				System.out.println("Triangulo Escaleno");
			}
		}
	}
}
