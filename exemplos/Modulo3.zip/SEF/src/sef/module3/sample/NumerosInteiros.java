package sef.module3.sample;
//Fazer um programa para ler um vetor de 8 n�meros 
//inteiros. Imprimir na tela os conte�dos do vetor lido, a soma de seus 
//elementos e apresentar quantos deles s�o pares.
//inteiro vetor[] = {1, 22, -4, 5, -17, 8, 91, -10}
public class NumerosInteiros {

	public static void main(String[] args) {
		int vetor[] = {1, 22, -4, 5, -17, 8, 91, -10};
		int soma = 0;
		int par  = 0;
		
		for (int i=0; i<8; i++) {
	        System.out.println(vetor[i]);
			soma = soma + vetor[i];
			par = (vetor[i] % 2 == 0)?par + 1 :par;
		}

        System.out.println("Pares:"+par);
        System.out.println("Soma:"+soma);
	}
}
