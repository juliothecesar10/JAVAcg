package sef.module3.sample;

public class PolimorfismoExemplo2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
        int x = 0;
        float y = 0;
        String z = "0";
        PolimorfismoExemplo2 m = new PolimorfismoExemplo2();
        m.varType(x);
        m.varType(y);
        m.varType(z);
	}
    public void varType(float var){
        System.out.println("Is an float!");
    }

    public void varType(int var){
        System.out.println("Is an int!");
    }

    public void varType(String var){
        System.out.println("Is an string!");
    }
}
