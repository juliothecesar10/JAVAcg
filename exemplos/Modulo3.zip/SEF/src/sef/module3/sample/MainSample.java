/*
 * Created on Jan 31, 2022
 *
 * Hello World Program
 */

package sef.module3.sample;


/**
 * @author John Doe
 */
public class MainSample {

	public static void main(String[] args) {
		int x = 5;
		System.out.println(x);
		x++;
		System.out.println(x);
		++x;
		System.out.println(x);
	}

}