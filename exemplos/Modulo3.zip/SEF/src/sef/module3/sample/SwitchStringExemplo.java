package sef.module3.sample;

public class SwitchStringExemplo {
	public static void main(String[] args) {
		// Declarando vari�vel String
		String levelString = "Expert";
		int level = 0;
		// Usando String no switch
		switch (levelString) {
		// Usando String no case
		case "Beginner":
			level = 1;
			break;
		case "Intermediate":
			level = 2;
			break;
		case "Expert":
			level = 3;
			break;
		default:
			level = 0;
			break;
		}
		System.out.println("Seu n�vel e: " + level);
	}
}