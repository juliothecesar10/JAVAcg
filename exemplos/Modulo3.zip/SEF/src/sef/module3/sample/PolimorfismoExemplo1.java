package sef.module3.sample;

public class PolimorfismoExemplo1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
        int x = 0;
        float y = 0;
        String z = "0";
        varType(x);
        varType(y);
        varType(z);
	}
    public static void varType(float var){
        System.out.println("Is an float!");
    }

    public static void varType(int var){
        System.out.println("Is an int!");
    }

    public static void varType(String var){
        System.out.println("Is an string!");
    }
}
