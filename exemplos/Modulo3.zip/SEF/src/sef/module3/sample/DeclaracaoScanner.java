package sef.module3.sample;

import java.util.Scanner;

public class DeclaracaoScanner {
	  public static void main(String[] args) {
		    Scanner myObj = new Scanner(System.in);

		    System.out.println("Enter name, age and salary:");

		    // String input
		    System.out.println("Informe o nome:");
		    String name = myObj.nextLine();

		    // Numerical input
		    int age;
		    while (true) {
			    System.out.println("Informe a Idade:");
			    age = myObj.nextInt();
			    if (age < 0) {
			    	System.out.println("Idade n�o pode ser negativa!!");
			    } else {
			    	break;
			    }
		    };	    
		    System.out.println("Informe o Salario:");
		    double salary = myObj.nextDouble();

		    // Output input by user
		    System.out.println("Name: " + name);
		    System.out.println("Age: " + age);
		    System.out.println("Salary: " + salary);
		  }
}