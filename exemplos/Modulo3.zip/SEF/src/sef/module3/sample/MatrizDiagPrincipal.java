package sef.module3.sample;
//Fazer um programa para ler um vetor de 8 n�meros 
//inteiros. Imprimir na tela os conte�dos do vetor lido, a soma de seus 
//elementos e apresentar quantos deles s�o pares.
//inteiro vetor[] = {1, 22, -4, 5, -17, 8, 91, -10}
public class MatrizDiagPrincipal {

	public static void main(String[] args) {
		char matriz[][] = new char[3][3];
		for (int x=0; x<3; x++) {
			for (int i=0; i<3; i++) {
				if (x==i) {
					matriz[x][i] = 'X';
				} else {
					matriz[x][i] = 'b';					
				}
			}
		}
		for (int x=0; x<3; x++) {
			for (int i=0; i<3; i++) {
				System.out.print(matriz[x][i]+" ");					
			}
			System.out.println(" ");
		}	
	}
}
