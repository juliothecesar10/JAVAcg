package acc.br.bigdecimal;

import java.math.BigDecimal;

public class MeuBigDecimal01 {
    public static void main(String[] args) {
		
    	BigDecimal bd = new BigDecimal("-36755");
    			
		System.out.println(bd + " O tipo é  " + bd.getClass());

    }
}
