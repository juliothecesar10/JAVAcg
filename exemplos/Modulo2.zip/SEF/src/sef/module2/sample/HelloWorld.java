package sef.module2.sample;

public class HelloWorld {
	
	public static void main(String arg[]) {

		int n1 = 10;
		int n2 = 7;
		int n3 = 1;

		if (n1 > n2)
		{
			if (n1 > n3)
			{
				System.out.println("$n1 é o maior ");
			} else {
				System.out.println("$n3 é o maior ");
			}
		} else {
			System.out.println("entrou no else");
			System.out.println("$n2 é o maior ");
		}
		
	}
}   