package sef.module2.sample;

public class HelloWorld4 {

	public static void main(String[] args) {
		
		System.out.println("Hello MUNDO!!!");

	}

}
