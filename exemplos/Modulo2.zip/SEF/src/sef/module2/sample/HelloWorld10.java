package sef.module2.sample;

public class HelloWorld10 {

	public static void main(String[] args) {
		int A = 10;
		float B = 20.5f;
	    float C = A + B;
		System.out.println("Valor de C = "+C);

	}

}
