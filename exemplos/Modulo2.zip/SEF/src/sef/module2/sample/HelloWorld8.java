package sef.module2.sample;

public class HelloWorld8 {

	public static void main(String[] args) {
		int a = 5;
		int soma;
		
		soma = a + 10;
		
		System.out.println("Soma = " + soma);

	}

}
