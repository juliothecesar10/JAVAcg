package sef.module2.sample;

public class Hello {

	public static void main(String[] args) {
        System.out.println("hello world");

	}

}
