package sef.module2.sample;

public class HelloMundo {

	public static void main(String[] args) {
				
		int x = 5;
		int y = 0;
		

		String nome = "Julio";
		
		System.out.println(y);
	}
 
}
