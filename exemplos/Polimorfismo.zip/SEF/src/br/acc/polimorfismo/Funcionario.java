package br.acc.polimorfismo;

//public abstract class Funcionario {
public class Funcionario {

	private double salario;

	public double calculaSalario() {
		this.salario = 500.00;
		return salario;
	}
}
