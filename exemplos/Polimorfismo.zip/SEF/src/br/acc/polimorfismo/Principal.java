package br.acc.polimorfismo;

public class Principal {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Funcionario fc = new Funcionario();
		Gerente     ge = new Gerente();
		Vendedor    ve = new Vendedor();
		
		System.out.println(fc.calculaSalario());
		System.out.println(ve.calculaSalario());
		System.out.println(ge.calculaSalario());

	}

}
