package br.acc.polimorfismo;

public class Gerente extends Funcionario{
	
	@Override
	public double calculaSalario() {
		return super.calculaSalario() + 1600.00; 
	}
	
}
