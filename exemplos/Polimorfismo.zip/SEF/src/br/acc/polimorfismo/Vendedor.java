package br.acc.polimorfismo;

public class Vendedor extends Funcionario{
	
	@Override
	public double calculaSalario() {
		return super.calculaSalario() + 600.00; 
	}
}
