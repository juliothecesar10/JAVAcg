package acc.br.escopo;

public class Escopo07 {

	public static String nome;
	public static int idade;
	
    public static void main(String[] args) {
        nome = "Patrícia";
        idade = 22;

        System.out.println(Escopo07.falar());
        Escopo07.andar();
    }

    public static String falar() {
        String frase = "Olá mundo!";
        return frase;
    }

    private static void andar() {
        System.out.println(nome + " está andando.");
    }
}
