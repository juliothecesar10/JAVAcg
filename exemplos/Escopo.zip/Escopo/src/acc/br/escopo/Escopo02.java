package acc.br.escopo;

public class Escopo02 {

	public static void main(String[] args) {
		String nome;
		int idade;
		
		nome  = "Patrícia";
		idade = 22;
	}
	
	public String falar() {
		String frase = "Ola mundo!";
		return frase;
	}

	private void andar() {
		System.out.println(nome + frase);
	}


}
