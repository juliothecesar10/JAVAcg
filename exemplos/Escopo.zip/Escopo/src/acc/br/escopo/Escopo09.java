package acc.br.escopo;

public class Escopo09{

	public static String nome;
	public static int idade;
	
    public static void main(String[] args) {
        nome = "Patrícia";
        idade = 22;

        Escopo09 escopo = new Escopo09();
        System.out.println(escopo.falar());
        escopo.andar();
    }

    public String falar() {
        String frase = "Olá mundo!";
        return frase;
    }

    private void andar() {
        System.out.println(nome + " está andando.");
    }
}
