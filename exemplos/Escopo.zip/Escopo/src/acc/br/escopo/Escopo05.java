package acc.br.escopo;

public class Escopo05 {

	public static String nome;
	public static int idade;
	
	public static void main(String[] args) {
		nome  = "Patrícia";
		idade = 22;
	}
	
	public String falar() {
		String frase = "Ola mundo!";
		return frase;
	}

	private void andar() {
		String frase = "Estou andando!";
		System.out.println(nome + frase);
	}

}
