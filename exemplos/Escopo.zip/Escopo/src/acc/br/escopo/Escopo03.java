package acc.br.escopo;

public class Escopo03 {
	public String nome;
	public int idade;
	
	public static void main(String[] args) {
		
		nome  = "Patrícia";
		idade = 22;
	}
	
	public String falar() {
		String frase = "Ola mundo!";
		return frase;
	}

	private void andar() {
		System.out.println(nome + frase);
	}

}
