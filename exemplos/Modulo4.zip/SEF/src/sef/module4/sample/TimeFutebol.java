package sef.module4.sample;

public class TimeFutebol {
    private String nomeTime;
    private int idadeTime;
    
    public TimeFutebol() {

    }
       
	public String getNomeTime() {
		return nomeTime;
	}
	public void setNomeTime(String nomeTime) {
		this.nomeTime = nomeTime;
	}
	public int getIdadeTime() {
		return idadeTime;
	}
	public void setIdadeTime(int idadeTime) {
		this.idadeTime = idadeTime;
	}
    
    public void exibirDados() {
    	System.out.println("Nome do Time :" + this.nomeTime);
    	System.out.println("Idade do TIme:" + this.idadeTime);
    }
}
