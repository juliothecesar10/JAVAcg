package sef.module4.sample;

import java.util.Date;

public class ContaCorrente {
	private int numero;
	private String nome;
	private double Saldo;
	private Date Data;
	
	public ContaCorrente(int numero, String nome, double saldo, Date data) {
		super();
		this.numero = numero;
		this.nome = nome;
		this.Saldo = saldo;
		Data = data;
	}
	public void Depositar(double valorDeposito){
		Saldo = Saldo + valorDeposito;
	}
	public void Sacar(double valorSaque) {
		Saldo = Saldo - valorSaque;
	}
	public void ExibirSaldo() {
		System.out.println("Saldo Atual = "+Saldo);
	}
	public void Transferir(int idContaOrigem, int idContaDestino, Double valor) {
		// Retirar da conta origem 
		// Depositar na conta destino
		// Caso a origem fique negativa cancelar a transferencia
	}
	
	public int getNumero() {
		return numero;
	}
	public void setNumero(int numero) {
		this.numero = numero;
	}
	public String getNome() {
		return nome;
	}
	public void setNome(String nome) {
		this.nome = nome;
	}
	public double getSaldo() {
		return Saldo;
	}
	public void setSaldo(double saldo) {
		Saldo = saldo;
	}
	public Date getData() {
		return Data;
	}
	public void setData(Date data) {
		Data = data;
	}
	
}
