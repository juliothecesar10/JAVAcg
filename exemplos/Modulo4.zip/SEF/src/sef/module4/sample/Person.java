package sef.module4.sample;

import java.util.Calendar;

public class Person {

	//Attributes
	private String name;
	private int idade;
	private char sexo;
	
	//Behavior
	public Person(){
		
	}

	public Person(String name){
		this.name = name;
	}
	
	public Person(String name,int idade){
		this.name = name;
		this.idade= idade;
	}
	
	public Person(String name, int idade, char sexo) {
		this.name = name;
		this.idade = idade;
		this.sexo = sexo;
	}

    
	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public int getIdade() {
		return idade;
	}

	public void setIdade(int idade) {
		this.idade = idade;
	}

	public char getSexo() {
		return sexo;
	}

	public void setSexo(char sexo) {
		this.sexo = sexo;
	}

	public String introduce(){
		return "My name is " + name;
	}

	public String qual_Idade() {
		return "Person [idade=" + idade + "]";
	}

	
	public String diga_Seu_Nome() {
		return "Meu nome �: " + name;
	}
	
}
