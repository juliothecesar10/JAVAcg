package sef.module4.sample;

import java.util.Scanner;

public class PrincipalTime {

	public static void main(String[] args) {
		String nomeTime;
		int idadeTime;
		TimeFutebol time1 = new TimeFutebol();
		Scanner nome  = new Scanner(System.in);
		System.out.println("Qual o seu time? ");
		nomeTime = nome.nextLine();
		
		System.out.println("Qual a idade do seu time ? ");
		idadeTime = nome.nextInt();
		
		time1.setNomeTime(nomeTime);
        time1.setIdadeTime(idadeTime);
		time1.exibirDados();

	}

}
