package sef.module4.sample;

import java.util.Date;

public class ContaCorrente2 {
	private int numero;
	private ClienteConta cliente;
	private double saldo;
	private Date data;
	

	public ContaCorrente2(int numero, ClienteConta cliente, double saldo, Date data) {
		super();
		this.numero = numero;
		this.cliente = cliente;
		Saldo = saldo;
		Data = data;
	}
	
	public void Depositar(double valorDeposito){
		Saldo = Saldo + valorDeposito;
	}
	public void Sacar(double valorSaque) {
		Saldo = Saldo - valorSaque;
	}
	public void ExibirSaldo() {
		System.out.println("Saldo Atual = "+Saldo);
	}
	public void Transferir(int idContaOrigem, int idContaDestino, Double valor) {
		// Retirar da conta origem 
		// Depositar na conta destino
		// Caso a origem fique negativa cancelar a transferencia
	}
	
	public int getNumero() {
		return numero;
	}
	public void setNumero(int numero) {
		this.numero = numero;
	}


	public ClienteConta getCliente() {
		return cliente;
	}

	public void setCliente(ClienteConta cliente) {
		this.cliente = cliente;
	}

	public double getSaldo() {
		return Saldo;
	}
	public void setSaldo(double saldo) {
		Saldo = saldo;
	}
	public Date getData() {
		return Data;
	}
	public void setData(Date data) {
		Data = data;
	}
	
}
