package sef.module4.sample;

public class ThisPessoaPrincipal {

	public static void main(String[] args) {
		ThisPessoa ze = new ThisPessoa("ze");
		
		ThisPessoa zeNinguem = new ThisPessoa();
		
		System.out.println(ze);
		
		System.out.println(zeNinguem);
	}

}
