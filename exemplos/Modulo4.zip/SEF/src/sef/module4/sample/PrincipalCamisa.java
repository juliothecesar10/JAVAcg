package sef.module4.sample;

public class PrincipalCamisa {

	public static void main(String[] args) {
		Camisa botafogo = new Camisa("Preto","Botafogo",'M',191.98);

//		botafogo.exibirCamisa();
		
		System.out.println(botafogo.getNomeCamisa());
		
		double total = botafogo.getValor() * 2;
		
		System.out.println(total);
	
	}
}
