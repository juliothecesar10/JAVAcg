package sef.module4.sample;

public class Dono {
	private String nomeDono;
	private int idade;
	
	public Dono(String nomeDono, int idade) {
		this.nomeDono = nomeDono;
		this.idade = idade;
	}

	public String getNomeDono() {
		return nomeDono;
	}

	public void setNomeDono(String nomeDono) {
		this.nomeDono = nomeDono;
	}

	public int getIdade() {
		return idade;
	}

	public void setIdade(int idade) {
		this.idade = idade;
	}
	
	
}
