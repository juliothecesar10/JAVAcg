package sef.module4.sample;

public class CanetaException extends RuntimeException {
     public CanetaException(String message) {
    	 super(message);
     }
}
