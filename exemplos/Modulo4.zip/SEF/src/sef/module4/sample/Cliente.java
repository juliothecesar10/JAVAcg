package sef.module4.sample;

public class Cliente {

	private String nome;
	private int cpf;
	private String sobrenome;

	public Cliente(String nome, int cpf, String sobrenome) {
		this.nome = nome;
		this.cpf = cpf;
		this.sobrenome = sobrenome;
	}
		
	public String getNome() {
		return nome;
	}
	
	public void setNome(String nome) {
		this.nome = nome;
	}

	public int getCpf() {
		return cpf;
	}
	public void setCpf(int cpf) {
		this.cpf = cpf;
	}
	
	public String getSobrenome() {
		return sobrenome;
	}
	
	public void setSobrenome(String sobrenome) {
		this.sobrenome = sobrenome;
	}

	public void comprar() {
		
		System.out.println("Comprando ....");
		
	}
	
}
