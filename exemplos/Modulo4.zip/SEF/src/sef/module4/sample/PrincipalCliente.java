package sef.module4.sample;

public class PrincipalCliente {

	public static void main(String[] args) {
		
			Cliente c1 = new Cliente("Z�", 123456789, "Man�");
			
			c1.comprar();
			
			System.out.println(c1.getNome());
			System.out.println(c1.getCpf());
			System.out.println(c1.getSobrenome());
			
			c1.setCpf(987654321);
			
			Cliente c2 = new Cliente("J�lio C�sar", 123456789, "Ferreira");
			
			c2.comprar();
			
			System.out.println(c2.getNome());
			System.out.println(c2.getCpf());
			System.out.println(c2.getSobrenome());
			
			c2.setCpf(987623367);
	}

	
}
