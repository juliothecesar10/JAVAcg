package sef.module4.sample;

public class ClienteConta {
	private String nome;
	private int cpf;
	private String sobreNome;
	
	public ClienteConta() {
	}

	public ClienteConta(String nome, int cpf, String sobreNome) {
		super();
		this.nome = nome;
		this.cpf = cpf;
		this.sobreNome = sobreNome;
	}

	public String getNome() {
		return nome;
	}

	public void setNome(String nome) {
		this.nome = nome;
	}

	public int getCpf() {
		return cpf;
	}

	public void setCpf(int cpf) {
		this.cpf = cpf;
	}

	public String getSobreNome() {
		return sobreNome;
	}

	public void setSobreNome(String sobreNome) {
		this.sobreNome = sobreNome;
	}
	
	
}
