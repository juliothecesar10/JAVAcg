package sef.module4.sample;

public class Camisa {
	private String cor;
	private String nomeCamisa;
	private char tamanho;
	private double valor;

	public Camisa() {
		
	}
	
	public Camisa(String cor, String nomeCamisa, char tamanho, double valor) {
		this.cor        = cor;
		this.nomeCamisa = nomeCamisa;
		this.tamanho    = tamanho;
		this.valor      = valor;
	}

	public String getCor() {
		return cor;
	}

	public void setCor(String cor) {
		this.cor = cor;
	}

	public String getNomeCamisa() {
		return nomeCamisa;
	}

	public void setNomeCamisa(String nomeCamisa) {
		this.nomeCamisa = nomeCamisa;
	}

	public char getTamanho() {
		return tamanho;
	}

	public void setTamanho(char tamanho) {
		this.tamanho = tamanho;
	}

	public double getValor() {
		return valor;
	}

	public void setValor(double valor) {
		this.valor = valor;
	}

	public void exibirCamisa() {
		System.out.println("Cor = "+ cor);
		System.out.println("Nome = "+ nomeCamisa);
		System.out.println("Tamanho = "+ tamanho );
		System.out.println("Valor = "+ valor );
	}
}
