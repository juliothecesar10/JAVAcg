package sef.module4.sample;

public class VarArgsQuiz {

	public static void main(String[] args) {
		metodo(1,2,3);

	}

	public static void metodo(int ... v) {
		System.out.println("int");
		for(int n : v)
			System.out.println(n);
	}

	public static void metodo(boolean ... v) {
		System.out.println("bool");
		for (boolean b : v)
			System.out.println(b);
	}
	
}
