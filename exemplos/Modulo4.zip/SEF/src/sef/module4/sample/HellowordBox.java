package sef.module4.sample;

import javax.swing.JOptionPane;

public class HellowordBox {

	public static void main(String[] args) {
		
		JOptionPane.showMessageDialog(null, "Hello \nworld ");

	}

}
