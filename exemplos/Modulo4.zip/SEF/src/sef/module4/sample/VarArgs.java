package sef.module4.sample;

public class VarArgs {
	static void fun1(int... a1) {
		System.out.println("N�mero de argumentos: " + a1.length);
		for (int i1 : a1)
			System.out.print(i1 + " ");
		System.out.println();
	}

	public static void main(String[] args) {
		fun1(1000);
		fun1(11, 12, 13, 14);
		fun1();
	}

}
