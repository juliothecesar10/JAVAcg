package sef.module4.sample;

public class PrincipalCamisaOLD {

	public static void main(String[] args) {

//		Camisa botafogo = new Camisa("Botafogo", 'V', "M", 100.00f);
//				
//		botafogo.exibir();
		
		CamisaOLD santos = new CamisaOLD();
		santos.setDescricao("Santos");
		santos.setCor('B');
		santos.setTamanho("G");
		santos.setValor(89.00f);
		
		System.out.println(santos.getDescricao());

	}
}
