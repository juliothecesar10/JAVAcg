package sef.module4.sample;

public class ThisPessoa {
	String nome;

	public ThisPessoa() {
		//this("Sem nome");
	}

	public ThisPessoa(String nome) {
		this.nome = nome;
	}
	
}
