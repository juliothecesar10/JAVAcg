package sef.module4.sample;

public class DriverShirt {

	public static void main(String[] args) {
	
		Shirt botafogo = new Shirt("botafogo", 'P', 130);
		
		botafogo.Exibir();

	}

}
