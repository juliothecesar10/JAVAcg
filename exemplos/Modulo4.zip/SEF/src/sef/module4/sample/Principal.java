package sef.module4.sample;

public class Principal {

	public static void main(String[] args) {
		
		Shirt camisa = new Shirt("Botafogo",'P', 369.99);
		camisa.Exibir();
		camisa.Exibir();
	}

}
