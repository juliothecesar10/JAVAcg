package sef.module4.sample;

public class CamisaOLD {
	private String descricao;
	private char cor;
	private String tamanho;
	private float valor;
	
	public String getDescricao() {
		return descricao;
	}

	public void setDescricao(String descricao) {
		this.descricao = descricao;
	}

	public char getCor() {
		return cor;
	}

	public void setCor(char cor) {
		this.cor = cor;
	}

	public String getTamanho() {
		return tamanho;
	}

	public void setTamanho(String tamanho) {
		this.tamanho = tamanho;
	}

	public float getValor() {
		return valor;
	}

	public void setValor(float valor) {
		this.valor = valor;
	}

	public CamisaOLD() {

	}
	
	public CamisaOLD(String descricao, char cor, String tamanho, float valor) {
		this.setDescricao(descricao);
		this.setCor(cor);
		this.setTamanho(tamanho);
		this.setValor(valor);
	}
	
	public void exibir() {
		System.out.println("Descri��o da Camisa " + descricao);
		System.out.println("Cor da Camisa " + cor);
		System.out.println("Tamanho da Camisa " + tamanho);
		System.out.println("Valor da Camisa " + valor);
	}

	public void lavar() {
		System.out.println("A Camisa do "+ descricao + " esta lavando...");
	}
}
