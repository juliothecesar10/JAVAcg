package sef.module4.sample;

import java.util.Calendar;

public class ClassInstanceSample {

	public static void main(String arg[]){
		
		//Object instance creation using 'new' and passing parameters to constructors
		Person him = new Person("John Doe");
		Person her = new Person("Jane Doe",30);
		Person ela = new Person("Ana", 22, 'F'); 
		Person pessoa = new Person();
		pessoa.setName("Joao");
		her.setIdade(20);
		
		boolean isComplte = false;
		
		Person Homen = new Person("Jose",24);
		
		//Access an object's member method to invoke a behavior
		System.out.println(him.introduce());
		System.out.println(her.introduce());
		System.out.println(Homen.introduce());
		
		System.out.println(Homen.qual_Idade());
		// Access and Set the object's attribute using it's setter and getter
//		him.setName("Joao");
//		him.setIdade(25);
		String name = him.getName();
		System.out.println(name);
		int id = him.getIdade();
		System.out.println(id);

		System.out.println(Homen.diga_Seu_Nome());
		System.out.println(him.diga_Seu_Nome());
		
		System.out.println(Homen.qual_Idade());
		System.out.println(her.getIdade());
		
		//This will cause the object pointed by 'her' to be garbage collected
		//since there are no more remaining references to that object
		her = null;
				
		
		
	}
}
