/**
 * 
 */
package sef.module3.activity;

/**
 * @author 
 *
 */
public class VariableAssignmentActivity {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
	
//		// 1- Declare a variable of type int and assign it default value.
//		int variavel_A = 10;
//		// 2- Update the value
//		variavel_A = 20 + 1;
//		// 3- Print updated value to the console
//		System.out.printf("Valor : %d\n", variavel_A);
		
		double a = 2.9;
		int b;
		b = (int) a;
		System.out.println(b);
		System.out.println(a);
		
//		int quantidade = 2;
//		double preco = 9.99;
//		
//		double total;
//		total = quantidade * preco;
//		System.out.println(total);
		
//		int x;
//		int y;
		
//		x = 10;
//		y = 2;
//		y = x + 1;
//		System.out.println(y + " "+ x);
//		y = ++x; 
//		System.out.println(y + " "+ x);
//		y = x++; 
//		System.out.println(y + " "+ x);
//		y += x;
//		y = y + x;
//		System.out.println(y +"\n"+ x );

//		int A = 20;
//		int B = 3;
//		
//		int resultado = (10 + A * B) + 3 + 3;
//		
//		System.out.println(resultado);

//		int x, y;
//		x = 5;
//		y = 0;
//		
//		y = (x>1)?1:0;
//		System.out.println(y);
//		String texto = (x>1)?"sim":"nao";
//		
//		System.out.println(texto);
		
//		int x = 2;
//		int y = 0;
//		boolean test = x < y;
//		System.out.println(test);
		
		int x = 2;
//		int y = 0;
//		int w = 1;
//		boolean test = (x < y) || (y > w) || (x < w);
//		System.out.println(x);
	}
}