package sef.module3.activity;

/**
 * @author 
 *
 */
public class OperatorActivity {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		
		// Declare numbers to be operated
		int i = 5;
		int j = 4;
		
		// Subtract numbers
		int result = 0;
		
		if (i > j) {
			result = i-j;
		}
		
		// Print result
		System.out.println("Difference = " + result);
		
		// Add numbers
		result = i + j;
		
		boolean teste;
		teste = (i != j) || (i > j) ;
		System.out.println(teste);
		
		String texto = (i != j) && (i > j)?"Diferente":"Igual";
		System.out.println(texto);
		
		// Print result
		System.out.println("Soma = " + result);
	}
}